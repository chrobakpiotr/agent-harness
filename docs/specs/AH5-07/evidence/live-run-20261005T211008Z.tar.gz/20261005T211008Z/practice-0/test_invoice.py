import unittest

from invoice import total_cents


class TotalTest(unittest.TestCase):
    def test_whole_prices(self):
        self.assertEqual(total_cents([(2.0, 3), (5.0, 1)]), 1100)

    def test_fractional_price_is_not_truncated(self):
        self.assertEqual(total_cents([(19.99, 1)]), 1999)

    def test_every_two_decimal_price_converts_exactly(self):
        for cents in range(10000):
            with self.subTest(cents=cents):
                self.assertEqual(total_cents([(cents / 100, 1)]), cents)

    def test_discount_rounds_down(self):
        self.assertEqual(total_cents([(1.0, 1)], discount_percent=15), 85)


if __name__ == "__main__":
    unittest.main()
