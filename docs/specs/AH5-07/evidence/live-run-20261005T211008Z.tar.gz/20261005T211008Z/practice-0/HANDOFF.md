# Handoff: Invoice is one cent short

- Task ID: `ISSUE.md` ("Invoice is one cent short")
- Base: `83a69968d820760524b262f1a5f98c2b244cefa8` (main). Head: same commit. The changes are uncommitted in the working tree because the task said not to commit.
- Scope (allowed paths): `invoice.py`, `test_*.py`, `HANDOFF.md`
- Changed: `invoice.py` (1 line), `test_invoice.py` (2 tests added), `HANDOFF.md` (new)
- Status: **DONE** (awaiting independent evaluation; the builder does not accept its own work)

## Acceptance criteria → evidence

| AC | Evidence |
| --- | --- |
| `total_cents([(19.99, 1)])` returns `1999` | `test_fractional_price_is_not_truncated` passes. The direct repro command prints `1999`. Before the fix it printed `1998` on 3 of 3 runs. |

## Diagnosis

- Feedback loop: `python3 -c "from invoice import total_cents; print(total_cents([(19.99, 1)]))"`. Before the fix it printed `1998` every time. The scenario was already minimal: one line, qty 1, no discount.
- Hypotheses, ranked before testing:
  1. **Confirmed.** `price * 100` is a float just below the whole number, and `int()` truncates it. `19.99*100 == 1998.9999999999998` and `int()` turns it into `1998`.
  2. **Ruled out.** The discount path loses a cent even when `discount_percent=0`. `line_cents(19.99, 1)` already returns `1998` before any discount is applied.
  3. **Ruled out.** The `qty` multiplication loses the cent. `int(19.99*100)` is already `1998` before multiplying.
- Scope of the bug: 573 of the 10,000 prices from 0.00 to 99.99 were one cent short (for example 0.29, 0.57, 0.58). With `round()`, all 10,000 convert exactly.
- Fix: in `line_cents`, `int(price * 100)` became `round(price * 100)`.

## Tests

- `test_fractional_price_is_not_truncated`: the exact case from the issue.
- `test_every_two_decimal_price_converts_exactly`: a sweep over 0.00–99.99.
- Both failed before the fix (`FAILED (failures=574)`). Existing tests were not changed.

## Commands and results (after fix)

- `python3 -m unittest` → `Ran 4 tests in 0.970s` / `OK`
- `git diff --check` → no output (clean)
- No `[DEBUG-` instrumentation was added.

## Limitations / open decisions

- Prices are still floats. `round()` is correct for prices with at most 2 decimal places and normal magnitudes. It uses banker's rounding on exact halves, so sub-cent prices such as `0.125` would round to even. Accepting `Decimal` or integer-cent prices would be a contract change and needs a replan. I made no such change here.
- The discount rounding (floor) is unchanged.
