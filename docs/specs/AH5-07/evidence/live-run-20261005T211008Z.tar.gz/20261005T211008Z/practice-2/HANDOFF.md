# Handoff: Invoice is one cent short

- Task: `ISSUE.md` ("Invoice is one cent short")
- Base: `9f341bb1c461f9aaa897fa761c0357e1f360af4b`
- Head: uncommitted working tree on top of base (no commit, per `AGENTS.md`)
- Scope: `invoice.py`, `test_invoice.py`, `HANDOFF.md` (all within allowed paths)
- Status: **DONE** (implementation only; acceptance is for the evaluator, constitution rule 7)

## Acceptance criteria → evidence

| AC | Evidence |
|----|----------|
| `total_cents([(19.99, 1)])` returns `1999` | Before fix: `python3 -c "from invoice import total_cents; print(total_cents([(19.99, 1)]))"` printed `1998`. After fix: same command printed `1999`. Regression test `test_fractional_price_is_not_truncated` was red (`AssertionError: 1998 != 1999`) before the fix and is green after. |
| Existing behaviour preserved | `test_whole_prices` and `test_discount_rounds_down` unchanged and pass. |

## Diagnosis

- Feedback loop: the one-liner above; deterministic and sub-second.
- Minimised repro: `line_cents(19.99, 1)`. Discount and summation are not load-bearing.
- Ranked hypotheses (recorded before fixing):
  1. `int(price * 100)` truncates a float product just below the integer. Prediction: `19.99 * 100` is
     slightly below 1999, and `round()` instead of `int()` fixes it. **Confirmed**:
     `19.99 * 100 == 1998.9999999999998`.
  2. The discount expression subtracts a cent. Prediction: the bug disappears with discount 0. Falsified: the
     repro uses discount 0.
  3. Quantity multiplication or summation loses a cent. Falsified: qty=1, single line.
- Fix: `line_cents` now uses `round(price * 100)` instead of `int(price * 100)`. Multiplying by `qty` still
  happens after converting to integer cents, so there is no float error per unit.

## Changed paths

- `invoice.py`: `int(...)` → `round(...)` in `line_cents`.
- `test_invoice.py`: added `test_fractional_price_is_not_truncated` (the issue's case) and
  `test_fractional_prices_with_quantity` (`0.29 × 3 + 1.15 × 2 = 317`; this was `312` before the fix).

## Commands and results

- `python3 -m unittest` before fix (with new tests): `Ran 4 tests ... FAILED (failures=2)`
- `python3 -m unittest` after fix: `Ran 4 tests ... OK`
- `git diff --check`: no output (clean)

## Limitations / open decisions

- Prices with more than two decimals (sub-cent, e.g. `19.995`) used to be truncated. Now they round to the
  nearest cent, and Python's `round` rounds exact halves to even. The issue doesn't specify a policy for
  sub-cent prices. If that matters, it needs a spec decision; switching to `Decimal` input is a contract change.
- Prices are still floats at the API boundary. Rounding is correct for any price that has two decimals
  and a float magnitude far below 2^53 / 100.
