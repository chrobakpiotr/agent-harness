# Handoff

- Task ID: ISSUE.md — "Invoice is one cent short" (no formal ID in the packet)
- Base/head: base `e5b1d83`; head = `e5b1d83` + uncommitted working-tree changes (no commits, per AGENTS.md)
- Status: DONE (pending independent evaluation; builder does not approve its own work)

## Scope

Changed paths (all within allowed_paths):
- `invoice.py` — `line_cents` now uses `round(price * 100)` instead of `int(price * 100)`.
- `test_invoice.py` — added two regression tests.
- `HANDOFF.md` — this file.

## Root cause

`19.99 * 100` evaluates to `1998.9999999999998` in binary floating point; `int()` truncates
toward zero, giving 1998. Rounding to the nearest cent before multiplying by quantity fixes it.

## AC → evidence

| Acceptance criterion | Evidence |
| --- | --- |
| `total_cents([(19.99, 1)])` == 1999 | Reproduced 1998 before the fix; `test_fractional_price_not_truncated` passes after |
| Existing behaviour preserved (whole prices, discount rounds down) | `test_whole_prices`, `test_discount_rounds_down` still pass, unmodified |

Extra regression: `test_fractional_price_with_quantity` (`0.29` also truncates under the old code: 28 instead of 29).

## Commands and results

- `python3 -c "from invoice import total_cents; print(total_cents([(19.99,1)]))"` before the fix → `1998`
- `python3 -m unittest -v` after the fix → `Ran 4 tests ... OK`
- `git diff --check` → no output (clean)

## Limitations / assumptions

- Prices are still floats. `round()` is correct for any price with at most 2 decimal places that
  floats can represent closely (all realistic prices). Prices with sub-cent precision (e.g. 0.125)
  would be rounded half-to-even by Python's `round()`; the packet sets no rule for that.
- The discount rule (round discount down) is unchanged.

## Open decisions

- Whether to move the price input contract to `Decimal` or integer cents. That would change the
  public input contract, so it is out of scope for this packet and needs a replan.
