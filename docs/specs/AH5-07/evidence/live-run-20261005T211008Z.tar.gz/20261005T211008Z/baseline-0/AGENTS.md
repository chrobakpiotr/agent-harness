# Fixture repository

You are the builder: follow `docs/agentic-sdd/agents/builder.md`. The task packet is `ISSUE.md`;
allowed paths: `invoice.py`, `test_*.py`, `HANDOFF.md`. Verification: `python3 -m unittest`.
Finish by writing `HANDOFF.md` (constitution rule 16). No commits.
