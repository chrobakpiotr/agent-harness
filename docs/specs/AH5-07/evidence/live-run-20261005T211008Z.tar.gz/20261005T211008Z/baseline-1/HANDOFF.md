# Handoff

- **Task ID:** ISSUE.md — "Invoice is one cent short"
- **Base/head:** base `7b9a8a0147f5f58aa2d39924cf04da608ca4ea4e`; head = same commit plus uncommitted working-tree changes (no commit, per AGENTS.md)
- **Scope (allowed paths touched):** `invoice.py`, `test_invoice.py`, `HANDOFF.md`
- **Status:** DONE (pending independent evaluation; builder does not accept its own work)

## Root cause and change

`line_cents` converted float prices with `int(price * 100)`, which truncates. `19.99 * 100` is
`1998.9999999999998` in binary floating point, so it became 1998. Changed to
`round(price * 100)`, which converts to the nearest whole cent. Nothing else changed: the
discount logic (rounding the discount down) and the function signatures are the same.

## Acceptance criteria → evidence

| AC | Evidence |
|----|----------|
| `total_cents([(19.99, 1)]) == 1999` | `test_fractional_price_not_truncated` passes |
| Other fractional prices are not truncated either | `test_fractional_prices_with_quantities` (0.29×3, 1.15×2, 4.35×1, all of which truncate under the old code) passes |
| Existing behaviour unchanged | `test_whole_prices` and `test_discount_rounds_down` unchanged and passing |

## Commands and results

- New tests run against the original `invoice.py` (stashed temporarily): `python3 -m unittest` → `Ran 4 tests … FAILED (failures=2)`. This confirms the tests reproduce the bug.
- With the fix: `python3 -m unittest -v` → `Ran 4 tests … OK`
- `git diff --check` → no output (clean)

## Limitations / open decisions

- Prices are still floats. `round()` is correct for values with at most 2 decimal places, which is
  what the current `(price, qty)` contract implies. Prices with sub-cent precision (e.g. 0.125) would
  use Python's banker's rounding. Moving to `Decimal` or integer-cent inputs would change the
  public contract and needs a plan or packet change. I did not make that change here.
