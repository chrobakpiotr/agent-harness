import unittest

from invoice import total_cents


class TotalTest(unittest.TestCase):
    def test_whole_prices(self):
        self.assertEqual(total_cents([(2.0, 3), (5.0, 1)]), 1100)

    def test_fractional_price_not_truncated(self):
        self.assertEqual(total_cents([(19.99, 1)]), 1999)

    def test_fractional_prices_with_quantities(self):
        self.assertEqual(total_cents([(0.29, 3), (1.15, 2), (4.35, 1)]), 87 + 230 + 435)

    def test_discount_rounds_down(self):
        self.assertEqual(total_cents([(1.0, 1)], discount_percent=15), 85)


if __name__ == "__main__":
    unittest.main()
