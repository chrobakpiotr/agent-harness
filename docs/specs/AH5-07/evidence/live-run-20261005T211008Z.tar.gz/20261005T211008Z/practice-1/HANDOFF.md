# Handoff: Invoice is one cent short

- Task ID: `ISSUE.md` ("Invoice is one cent short")
- Base: `454ce24`. Head: `454ce24` plus uncommitted working-tree changes (no commit, per AGENTS.md)
- Scope: `invoice.py`, `test_invoice.py`, `HANDOFF.md`, all inside allowed paths
- Status: **DONE** (implementer evidence only; this still needs an independent evaluator, rule 7)

## Acceptance criterion → evidence

| AC | Evidence |
|----|----------|
| `total_cents([(19.99, 1)])` == 1999 | `test_fractional_price_is_not_truncated` was red before the fix (`AssertionError: 1998 != 1999`) and green after it. A direct call printed `1999`. |

## Diagnosis

- Loop: `python3 -m unittest` with the new regression tests. Before the fix it went red on the
  reported symptom, 1998 != 1999.
- Hypotheses, ranked before testing:
  1. `int(price * 100)` truncates a float slightly below the true value. Prediction: `19.99*100 < 1999`.
  2. The discount arithmetic loses a cent. Prediction: the bug disappears with `discount_percent=0`.
  3. The `qty` multiplication. Prediction: the bug disappears with `qty=1`.
- The repro uses discount 0 and qty 1, which rules out 2 and 3. A REPL probe confirmed 1:
  `19.99*100 == 1998.9999999999998` and `int(...) == 1998`. The same happens for 0.29, 1.15, 0.57
  and 4.35.
- **Correct hypothesis: #1.** Fix: `line_cents` now rounds to the nearest cent
  (`round(price * 100)`) instead of truncating.

## Commands and results

- `python3 -m unittest` before the fix: 4 tests, FAILED (failures=2)
- `python3 -m unittest` after the fix: 4 tests, OK
- `git diff --check`: no output (clean)

## Changes

- `invoice.py`: `int(price * 100)` became `round(price * 100)` in `line_cents`.
- `test_invoice.py`: added `test_fractional_price_is_not_truncated` (the exact case from the
  issue) and `test_fractional_prices_across_lines` (several affected prices, with qty > 1).
  The existing tests are unchanged.

## Limitations / open decisions

- Prices are still floats. The fix is correct for prices with at most 2 decimals. For
  sub-cent prices (e.g. 0.125), `round` uses banker's rounding on the float value, and the
  intended behaviour is unspecified. Taking `Decimal` or integer-cent input would be a
  contract change and needs a replan.
- The discount rounding behaviour is unchanged.
