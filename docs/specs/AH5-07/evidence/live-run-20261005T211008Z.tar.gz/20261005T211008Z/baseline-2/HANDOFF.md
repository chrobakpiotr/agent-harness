# Handoff

- **Task ID:** ISSUE.md — "Invoice is one cent short"
- **Base/head:** base `4e6c9a8709c1884a10066793691fcdb9f1adfec0`; head = same commit + uncommitted working-tree changes (no commit made, per AGENTS.md)
- **Status:** DONE (awaiting independent evaluation; builder does not accept its own work)

## Scope

Changed paths (all within allowed_paths):
- `invoice.py` — `line_cents` now uses `round(price * 100)` instead of `int(price * 100)`.
- `test_invoice.py` — added two regression tests.
- `HANDOFF.md` — this file.

## Root cause

`19.99 * 100` evaluates to `1998.9999999999998` in binary floating point; `int()` truncates
it to `1998`. Rounding the unit price to the nearest cent before multiplying by quantity fixes it.

## AC → evidence

| Acceptance criterion | Evidence |
|---|---|
| `total_cents([(19.99, 1)]) == 1999` | `test_fractional_price_not_truncated` — failed before the fix (`1998 != 1999`), passes after |
| No regression to other fractional prices/quantities | `test_fractional_prices_with_quantity` (`[(0.29, 3), (1.15, 2)]` → 317) — failed before (`312`), passes after |
| Existing behaviour kept (whole prices, discount rounds down) | `test_whole_prices`, `test_discount_rounds_down` unchanged and passing |

## Commands and results

- `python3 -m unittest` before the fix (with new tests): `Ran 4 tests` — `FAILED (failures=2)`
- `python3 -m unittest -v` after the fix: `Ran 4 tests` — `OK`
- `git diff --check`: no output (clean)

## Limitations / assumptions

- Assumes the price is meant to be a value in whole cents, so rounding to the nearest cent is
  correct. Prices with sub-cent precision (e.g. 0.125) are rounded per unit with Python's
  banker's rounding (`round` ties to even); the issue doesn't say what should happen there.
- The discount rounding (floor of discount amount) is unchanged.

## Open decisions

- Long-term, prices could be carried as `Decimal` or integer cents end-to-end to avoid float
  input entirely. That would change the public input contract, so it's out of scope here and
  needs a plan/packet decision.
